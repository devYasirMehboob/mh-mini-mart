<?php

declare(strict_types=1);
namespace App\Validators;
use App\Http\HttpException;
final class HeldSaleValidator
{
    private const METHODS=['cash','card','bank_transfer','mobile_wallet','other'];
    public function validate(array$input):array
    {
        $errors=[];$items=$input['items']??null;$token=trim((string)($input['request_token']??''));$discountType=(string)($input['discount_type']??'none');$discount=$this->decimal((string)($input['discount_value']??'0'),2);$method=(string)($input['payment_method']??'cash');$received=$this->decimal((string)($input['amount_received']??'0'),2);$name=trim((string)($input['customer_name']??''));$phone=trim((string)($input['customer_phone']??''));$notes=trim((string)($input['notes']??''));$reference=trim((string)($input['payment_reference']??''));
        if($token===''||strlen($token)<16||strlen($token)>100||preg_match('/^[A-Za-z0-9._:-]+$/',$token)!==1)$errors['request_token']=['Use a valid request token.'];if(!is_array($items)||$items===[])$errors['items']=['Add products before holding the sale.'];if(!in_array($discountType,['none','fixed','percentage'],true))$errors['discount_type']=['Select a valid discount type.'];if($discount===null||$discount<0||($discountType==='percentage'&&$discount>10000))$errors['discount_value']=['Enter a valid discount.'];if(!in_array($method,self::METHODS,true))$errors['payment_method']=['Select a valid payment method.'];if($received===null||$received<0)$errors['amount_received']=['Enter a valid received amount.'];if(mb_strlen($name)>150)$errors['customer_name']=['Customer name is too long.'];if($phone!==''&&(mb_strlen($phone)>30||preg_match('/^[0-9+() .-]{7,30}$/',$phone)!==1))$errors['customer_phone']=['Enter a reasonable customer phone.'];if(mb_strlen($notes)>1000)$errors['notes']=['Notes are too long.'];if(mb_strlen($reference)>150)$errors['payment_reference']=['Payment reference is too long.'];
        $merged=[];if(is_array($items))foreach($items as$i=>$item){if(!is_array($item)){$errors["items.$i"]=['Invalid item.'];continue;}$id=filter_var($item['product_id']??null,FILTER_VALIDATE_INT);$quantity=$this->decimal((string)($item['quantity']??''),3);if($id===false||$id<1){$errors["items.$i.product_id"]=['Invalid product.'];continue;}if($quantity===null||$quantity<=0){$errors["items.$i.quantity"]=['Quantity must be greater than zero.'];continue;}$merged[(int)$id]=($merged[(int)$id]??0)+$quantity;}
        if($errors!==[])throw new HttpException('Please correct the held sale details.',422,$errors);return['items'=>$merged,'request_token'=>$token,'discount_type'=>$discountType,'discount_value'=>$this->money($discount??0),'payment_method'=>$method,'payment_reference'=>$reference===''?null:$reference,'amount_received'=>$this->money($received??0),'customer_name'=>$name===''?null:$name,'customer_phone'=>$phone===''?null:$phone,'notes'=>$notes===''?null:$notes];
    }
    private function decimal(string$value,int$scale):?int{$value=trim($value);if(preg_match('/^\d+(?:\.(\d+))?$/',$value,$m)!==1)return null;$fraction=str_pad(substr($m[1]??'',0,$scale),$scale,'0');return(int)strstr($value.'.','.',true)*(10**$scale)+(int)$fraction;}
    private function money(int$cents):string{return intdiv($cents,100).'.'.str_pad((string)($cents%100),2,'0',STR_PAD_LEFT);}
}
